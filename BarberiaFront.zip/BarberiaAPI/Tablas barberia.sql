drop database if exists barberia;
create database barberia;
use barberia;
drop table if exists clientes;
CREATE TABLE clientes (
    id_cliente INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    cedula CHAR(10) NOT NULL UNIQUE,
    telefono CHAR(10) UNIQUE,
    direccion VARCHAR(30),
    preferencias VARCHAR(50),
    fecha_registro DATETIME NOT NULL DEFAULT GETDATE()
);

insert into clientes(nombre,cedula,telefono,direccion,preferencias)
values
( 'Lionel Messi', '10000001', '555-0001', 'Calle GOAT 10', 'Corte moderno' ),
( 'Cristiano Ronaldo','10000002', '555-0002', 'Avenida Champions 7', 'Fade alto' ),
( 'Neymar Jr', '10000003', '555-0003', 'Boulevard Samba 10', 'Desvanecido'),
('Kylian Mbappé', '10000004', '555-0004', 'Ruta del Gol 7', 'Corte clásico'),
( 'Zlatan Ibrahimović', '10000005', '555-0005', 'Plaza Zlatan 9', 'Corte con estilo' ),
( 'Erling Haaland', '10000006', '555-0006', 'Calle del Gol 9', 'Corte militar' ),
( 'Robert Lewandowski', '10000007', '555-0007', 'Avenida Polonia 10', 'Corte europeo' ),
( 'Kevin De Bruyne', '10000008', '555-0008', 'Paseo Bélgica 17', 'Corte formal' ),
( 'Mohamed Salah', '10000009', '555-0009', 'Calle Faraón 11', 'Corte egipcio' ),
( 'Luka Modrić', '10000010', '555-0010', 'Camino Croacia 8', 'Corte clásico' ),
( 'Karim Benzema', '10000011', '555-0011', 'Boulevard Balón de Oro 9', 'Corte degradado' ),
( 'Vinícius Jr', '10000012', '555-0012', 'Avenida Samba 20', 'Rulos definidos' ),
( 'Harry Kane', '10000013', '555-0013', 'Calle Wembley 10', 'Corte ejecutivo' ),
( 'Pedri González', '10000014', '555-0014', 'Ronda Juvenil 7', 'Corte juvenil' ),
( 'João Félix', '10000015', '555-0015', 'Pasaje Lisboa 21', 'Corte moderno' );

drop table if exists roles;
CREATE TABLE roles (
    id_rol INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(100) NOT NULL
);

INSERT INTO roles (nombre, descripcion)
VALUES 
('Administrador', 'Acceso total al sistema, puede gestionar usuarios y configuraciones'),
('Empleado', 'Acceso limitado a funcionalidades operativas del sistema'),
('Cliente', 'Acceso solo a visualización y operaciones personales');


drop table if exists usuarios;
CREATE TABLE usuarios (
    id_usuario INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    cedula CHAR(10) NOT NULL UNIQUE,
    telefono CHAR(10) UNIQUE,
    contrasena CHAR(8) NOT NULL,
    id_rol INT,
    FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
);

insert into usuarios( nombre, cedula, telefono, contrasena )
values
('Andrés Gómez', '20000001', '555-1010', 'agomez23'),
('Mariana Torres', '20000002', '555-1011', 'mtorres8'),
('Carlos Pérez', '20000003', '555-1012', 'carlopz1'),
('Laura Martínez', '20000004', '555-1013', 'lauramz7'),
('Juan Rodríguez', '20000005', '555-1014', 'juanrd10'),
('Camila Salazar', '20000006', '555-1015', 'camisal4'),
('Felipe Ríos', '20000007', '555-1016', 'friosx90'),
('Daniela Ruiz', '20000008', '555-1017', 'dani9021'),
('Mateo López', '20000009', '555-1018', 'mateolz5'),
('Valentina Mejía', '20000010', '555-1019', 'valemj12');


drop table if exists turnos;
create table turnos (
id_turno int NOT NULL IDENTITY(1,1) PRIMARY KEY ,
id_cliente  int not null ,
foreign key( id_cliente) references clientes(id_cliente),
id_usuario int not null,
foreign key( id_usuario ) references usuarios(id_usuario),
fecha date not null,
hora time not null,
tipo_corte varchar(30),
precio decimal(8,2), 
notas varchar(200)
);

INSERT INTO turnos(id_cliente, id_usuario, fecha, hora, tipo_corte, precio, notas)
VALUES
(1, 2, '2025-05-13', '09:00:00', 'Fade alto', 25000.00, 'Cliente puntual'),
(2, 3, '2025-05-13', '10:00:00', 'Corte clásico', 20000.00, 'Pide rebajar las patillas'),
(3, 1, '2025-05-13', '11:00:00', 'Corte moderno', 28000.00, 'Usar tijera, no máquina'),
(4, 5, '2025-05-13', '12:00:00', 'Desvanecido', 26000.00, 'Prefiere estilo anterior'),
(5, 4, '2025-05-13', '14:00:00', 'Corte militar', 22000.00, 'Muy corto atrás'),
(6, 6, '2025-05-14', '09:30:00', 'Corte europeo', 27000.00, 'Cliente nuevo'),
(7, 7, '2025-05-14', '10:30:00', 'Rulos definidos', 30000.00, 'Pide productos especiales'),
(8, 8, '2025-05-14', '11:30:00', 'Corte ejecutivo', 24000.00, 'Corte para entrevista'),
(9, 9, '2025-05-14', '13:00:00', 'Corte juvenil', 23000.00, 'Trae imagen de referencia'),
(10, 10, '2025-05-14', '15:00:00', 'Corte con estilo', 29000.00, 'Quiere diseño lateral');

drop table if exists pagos;
CREATE TABLE pagos (
    id_pago INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
    id_turno INT NOT NULL,
    monto DECIMAL(8,2),
    metodo_pago VARCHAR(20),
    fecha_pago DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (id_turno) REFERENCES turnos(id_turno)
);

INSERT INTO pagos(id_turno, monto, metodo_pago)
VALUES
(1, 25000.00,'Efectivo'),
(2, 20000.00, 'Tarjeta'),
(3,28000.00, 'Transferencia'),
(4,26000.00, 'Tarjeta'),
(5, 22000.00, 'Transferencia');

drop table if exists gastos;
CREATE TABLE gastos (
    id_gasto INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
    monto DECIMAL(8,2),
    fecha DATETIME NOT NULL DEFAULT GETDATE(),
    descripcion VARCHAR(200),
    comprobante VARCHAR(10),
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

INSERT INTO gastos(monto, descripcion, comprobante, id_usuario)
VALUES
(15000.00, 'Pago de alquiler oficina', 'ALQ123456', 1),
(2000.00, 'Compra de suministros de oficina', 'SUM987654', 2),
(500.00, 'Pago de internet mensual', 'INT202305', 3),
(3000.00, 'Mantenimiento de equipo de computo', 'MANT765432', 4);

drop table if exists horarios;
create table horarios(
id_horario int NOT NULL IDENTITY(1,1) PRIMARY KEY,
id_usuario int not null,
foreign key(id_usuario) references usuarios(id_usuario),
dia_Semana varchar(10),
hora_inicio time,
hora_fin time
);

INSERT INTO horarios(id_usuario, dia_Semana, hora_inicio, hora_fin)
VALUES
(1, 'Lunes', '08:00:00', '17:00:00'),
(2, 'Martes', '09:00:00', '18:00:00'),
(3, 'Miércoles', '08:30:00', '17:30:00'),
(4, 'Jueves', '08:00:00', '16:00:00'),
(5, 'Viernes', '10:00:00', '19:00:00'),
(6, 'Sábado', '09:00:00', '14:00:00');

select *from clientes