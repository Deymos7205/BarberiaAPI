﻿using BarberiaAPI.Data;
using BarberiaAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BarberiaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TurnosController : ControllerBase
    {
        private readonly BarberiaContext _context;

        public TurnosController(BarberiaContext context)
        {
            _context = context;
        }

        // GET: api/Turnos
        // Obtiene todos los turnos, pero solo con los IDs de cliente y usuario.
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Turno>>> GetTurnos()
        {
            // Eliminamos .Include(t => t.Cliente) y .Include(t => t.Usuario)
            // También eliminamos la proyección .Select() ya que no necesitamos NombreCliente/NombreUsuario de la API
            return Ok(await _context.Turnos.ToListAsync());
        }

        // GET: api/Turnos/5
        // Obtiene un turno por ID, solo con los IDs de cliente y usuario.
        [HttpGet("{id}")]
        public async Task<ActionResult<Turno>> GetTurno(int id)
        {
            // Eliminamos .Include() y la proyección .Select()
            var turno = await _context.Turnos.FirstOrDefaultAsync(t => t.Id == id);

            if (turno == null)
            {
                return NotFound();
            }
            return Ok(turno);
        }

        // POST: api/Turnos
        // Ingresar un nuevo turno
        [HttpPost]
        public async Task<ActionResult<Turno>> PostTurno(Turno turno)
        {
            _context.Turnos.Add(turno);
            await _context.SaveChangesAsync();

            // Ya no cargamos Cliente ni Usuario después de guardar
            // No necesitamos asignar NombreCliente/NombreUsuario aquí.
            return CreatedAtAction(nameof(GetTurno), new { id = turno.Id }, turno);
        }

        // PUT: api/Turnos/5
        // Actualizar un turno existente
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTurno(int id, Turno update)
        {
            if (id != update.Id) // Comparar con Id_Turno del modelo
            {
                return BadRequest("El ID en la URL no coincide con el ID en el cuerpo de la solicitud.");
            }

            var existingTurno = await _context.Turnos.FindAsync(id);

            if (existingTurno == null)
            {
                return NotFound();
            }

            // Actualizar las propiedades del turno existente
            existingTurno.ClienteId = update.ClienteId;
            existingTurno.UsuarioId = update.UsuarioId;
            existingTurno.Fecha = update.Fecha;
            existingTurno.Hora = update.Hora;
            existingTurno.TipoCorte = update.TipoCorte;
            existingTurno.Precio = update.Precio;
            existingTurno.Notas = update.Notas;

            _context.Entry(existingTurno).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TurnoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Turnos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTurno(int id)
        {
            var turno = await _context.Turnos.FindAsync(id);
            if (turno == null)
            {
                return NotFound();
            }

            _context.Turnos.Remove(turno);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Método auxiliar para verificar si un turno existe
        private bool TurnoExists(int id)
        {
            return _context.Turnos.Any(e => e.Id == id); // Usar Id_Turno para la comprobación
        }
    }
}