using BarberiaAPI.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configuraci�n de la base de datos
builder.Services.AddDbContext<BarberiaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("BarberiaConnection")));

// --- INICIO DE LA CONFIGURACI�N CORS ---
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowBarberiaFront", // Nombre de la pol�tica CORS
        policy =>
        {

            policy.WithOrigins("https://localhost:7125")
                  .AllowAnyHeader() 
                  .AllowAnyMethod(); // Permite cualquier m�todo HTTP (GET, POST, PUT, DELETE)
        });
});
// --- FIN DE LA CONFIGURACI�N CORS ---


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseRouting(); // 
app.UseCors("AllowBarberiaFront"); 
app.UseAuthorization(); 

app.MapControllers();

app.Run();