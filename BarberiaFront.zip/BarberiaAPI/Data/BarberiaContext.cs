﻿using Microsoft.EntityFrameworkCore;
using BarberiaAPI.Model;

namespace BarberiaAPI.Data
{
    public class BarberiaContext : DbContext
    {
        public BarberiaContext(DbContextOptions<BarberiaContext> options) : base(options) { }

        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<Turno> Turnos { get; set; }
        public DbSet<Pago> Pagos { get; set; }
        public DbSet<Gasto> Gastos { get; set; }
        public DbSet<Horario> Horarios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Cliente
            modelBuilder.Entity<Cliente>().ToTable("clientes");

            // Usuario
            modelBuilder.Entity<Usuario>().ToTable("usuarios");
            modelBuilder.Entity<Usuario>()
                .HasOne<Rol>()
                .WithMany()
                .HasForeignKey(u => u.RolId)
                .OnDelete(DeleteBehavior.Restrict);

            // Rol
            modelBuilder.Entity<Rol>().ToTable("roles");

            // Turno
            modelBuilder.Entity<Turno>().ToTable("turnos");
            modelBuilder.Entity<Turno>()
                .HasOne<Cliente>()
                .WithMany()
                .HasForeignKey(t => t.ClienteId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Turno>()
                .HasOne<Usuario>()
                .WithMany()
                .HasForeignKey(t => t.UsuarioId)
                .OnDelete(DeleteBehavior.Restrict);

            // Pago
            modelBuilder.Entity<Pago>().ToTable("pagos");
            modelBuilder.Entity<Pago>()
                .HasOne<Cliente>()
                .WithMany()
                .HasForeignKey(p => p.Id)
                .OnDelete(DeleteBehavior.Cascade);

            // Gasto
            modelBuilder.Entity<Gasto>().ToTable("gastos");

            // Horario
            modelBuilder.Entity<Horario>().ToTable("horarios");
            modelBuilder.Entity<Horario>()
                .HasOne<Usuario>()
                .WithMany()
                .HasForeignKey(h => h.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
