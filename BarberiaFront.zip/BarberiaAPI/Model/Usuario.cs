﻿namespace BarberiaAPI.Model
{
    public class Usuario{
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Cedula { get; set; }
        public string Contrasena { get; set; }
        public int RolId { get; set; }
        public string Nombre { get; set; }
    }


}
